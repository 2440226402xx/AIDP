import os
import pandas as pd
import numpy as np
from PIL import Image
import torch
import torch.nn as nn
import torch.optim as optim
from torchvision import models, transforms
from torch.utils.data import Dataset, DataLoader
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.utils.class_weight import compute_class_weight


class CustomDenseNet(nn.Module):
    def __init__(self, num_classes):
        super(CustomDenseNet, self).__init__()
        self.densenet = models.densenet121(pretrained=True)
        num_ftrs = self.densenet.classifier.in_features
        self.densenet.classifier = nn.Sequential(
            nn.Linear(num_ftrs, num_classes)
        )

    def forward(self, x):
        return self.densenet(x)


class CustomDataset(Dataset):
    def __init__(self, data_dir, labels_df, transform=None):
        self.data_dir = data_dir
        self.labels_df = labels_df
        self.transform = transform

    def __len__(self):
        return len(self.labels_df)

    def __getitem__(self, idx):
        img_name = os.path.join(self.data_dir, self.labels_df.iloc[idx, 0])
        image = Image.open(img_name)
        label = self.labels_df.iloc[idx, 1:].values.astype(np.float32)

        if self.transform:
            image = self.transform(image)

        return image, label


class FocalLoss(nn.Module):
    def __init__(self, alpha=1, gamma=2, logits=True, reduction='mean'):
        super(FocalLoss, self).__init__()
        self.alpha = alpha
        self.gamma = gamma
        self.logits = logits
        self.reduction = reduction

    def forward(self, inputs, targets):
        if self.logits:
            BCE_loss = nn.BCEWithLogitsLoss(reduction='none')(inputs, targets)
        else:
            BCE_loss = nn.BCELoss(reduction='none')(torch.sigmoid(inputs), targets)

        pt = torch.exp(-BCE_loss)
        F_loss = self.alpha * (1 - pt) ** self.gamma * BCE_loss

        if self.reduction == 'mean':
            return torch.mean(F_loss)
        elif self.reduction == 'sum':
            return torch.sum(F_loss)
        else:
            return F_loss


device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

data_dir = "/data/WSIimg/"
excel_path = "/data/labels.xlsx"

labels_df = pd.read_excel(excel_path)

label_cols = labels_df.columns[1:]
label_encoder = LabelEncoder()
for col in label_cols:
    labels_df[col] = label_encoder.fit_transform(labels_df[col])

train_df, val_df = train_test_split(labels_df, test_size=0.2, random_state=42)

transform = transforms.Compose([
    transforms.RandomVerticalFlip(p=0.5),
    transforms.RandomHorizontalFlip(p=0.5),
    transforms.RandomApply([transforms.RandomAffine(degrees=30, translate=(0.1, 0.1))], p=0.5),
    transforms.RandomRotation(degrees=30),
    transforms.RandomApply([transforms.ColorJitter(brightness=0.5, contrast=0.5, saturation=0.5, hue=0.5)], p=0.5),
    transforms.RandomApply([transforms.GaussianBlur(kernel_size=3)], p=0.5),
    transforms.RandomPerspective(),
    transforms.ToTensor(),
])


train_dataset = CustomDataset(data_dir, train_df, transform=transform)
val_dataset = CustomDataset(data_dir, val_df, transform=transform)

train_loader = DataLoader(train_dataset, batch_size=32, shuffle=True)
val_loader = DataLoader(val_dataset, batch_size=32)

num_classes = len(label_cols)
model = CustomDenseNet(num_classes).to(device)

class_weights = compute_class_weight('balanced', np.unique(train_df[label_cols]), train_df[label_cols])
class_weights = torch.tensor(class_weights, dtype=torch.float32).to(device)
criterion = FocalLoss(alpha=class_weights)

optimizer = optim.Adam(model.parameters(), lr=0.001)

# Calculate the number of samples for training and validation
total_samples = len(labels_df)
num_train_samples = int(total_samples * 0.8)
num_val_samples = total_samples - num_train_samples

# Generate indices for training and validation samples
indices = list(range(total_samples))
np.random.shuffle(indices)
train_indices = indices[:num_train_samples]
val_indices = indices[num_train_samples:]

# Define data samplers
train_sampler = sampler.SubsetRandomSampler(train_indices)
val_sampler = sampler.SubsetRandomSampler(val_indices)

# Create datasets and dataloaders with samplers
train_dataset = CustomDataset(data_dir, labels_df, transform=transform)
val_dataset = CustomDataset(data_dir, labels_df, transform=transform)

train_loader = DataLoader(train_dataset, batch_size=32, sampler=train_sampler)
val_loader = DataLoader(val_dataset, batch_size=32, sampler=val_sampler)

optimizer = optim.Adam(model.parameters(), lr=1e-4)
criterion = FocalLoss(alpha=class_weights)

# Learning rate scheduler
scheduler = lr_scheduler.StepLR(optimizer, step_size=50, gamma=0.1)

# Calculate the number of iterations per epoch
batch_size = 8
num_train_iterations = math.ceil(num_train_samples / batch_size)

total_iterations = 500
for iteration in range(total_iterations):
    model.train()
    running_loss = 0.0
    for batch_idx, (inputs, labels) in enumerate(train_loader):
        inputs, labels = inputs.to(device), labels.to(device)
        optimizer.zero_grad()
        outputs, _ = model(inputs)
        loss = criterion(outputs, labels)
        loss.backward()
        optimizer.step()
        running_loss += loss.item() * inputs.size(0)
        if (batch_idx + 1) % 50 == 0:  # Print loss every 50 batches
            print(f"Iteration [{iteration+1}/{total_iterations}], Batch [{batch_idx+1}/{num_train_iterations}], Loss: {running_loss / ((batch_idx+1) * batch_size):.4f}")
    epoch_loss = running_loss / num_train_samples
    print(f"Epoch {(iteration+1)*batch_size/num_train_iterations}/{total_iterations}, Train Loss: {epoch_loss:.4f}")

model.eval()
running_loss = 0.0
for inputs, labels in val_loader:
    inputs, labels = inputs.to(device), labels.to(device)
    outputs, _ = model(inputs)
    loss = criterion(outputs, labels)
    running_loss += loss.item() * inputs.size(0)
val_loss = running_loss / num_val_samples
print(f"Validation Loss: {val_loss:.4f}")
