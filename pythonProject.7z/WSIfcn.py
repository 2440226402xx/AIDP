import torch
import torch.nn as nn
from torchvision import models
from torchvision.transforms import transforms
from PIL import Image

# 定义DenseNet模型结构
class DenseNetFCN(nn.Module):
    def __init__(self):
        super(DenseNetFCN, self).__init__()
        self.features = models.densenet121().features
        self.classifier = nn.Conv2d(1024, 7, kernel_size=1)  # 假设有7个标签
        self.upsample = nn.Sequential(
            nn.ConvTranspose2d(7, 7, kernel_size=64, stride=32, padding=16, output_padding=0, bias=False),
            nn.Sigmoid()
        )

    def forward(self, x):
        x = self.features(x)
        x = self.classifier(x)
        x = self.upsample(x)
        return x

# 初始化模型并加载权重
fcn_model = DenseNetFCN()

# 载入预训练模型的参数
state_dict = torch.load('WSI.pth', map_location=torch.device('cpu'))
fcn_model.load_state_dict(state_dict)

# 固定FCN层的参数
for param in fcn_model.classifier.parameters():
    param.requires_grad = False

# 使用Xavier初始化FCN层参数
nn.init.xavier_uniform_(fcn_model.classifier.weight)  # 使用Xavier初始化方法

# 载入并处理一张图像
def load_image(image_path):
    transform = transforms.Compose([
        transforms.Resize((224, 224)),
        transforms.ToTensor(),
    ])
    image = Image.open(image_path)
    image = transform(image).unsqueeze(0)  # 增加批次维度
    return image

# 预测
def predict(image_path):
    image = load_image(image_path)
    fcn_model.eval()
    with torch.no_grad():
        output = fcn_model(image)
    return output

# 使用示例
output_map = predict('/data/testset/WSIimage.jpg')
print(output_map.shape)  # 输出形状应为[1, 7, 224, 224]，表示7个标签的224x224热图
