import os
import random

def generate_random_binary_file(file_path, size):
    with open(file_path, 'wb') as f:
        for _ in range(size):
            bit = random.randint(0, 1)
            f.write(bit.to_bytes(1, byteorder='big'))

if __name__ == "__main__":
    file_path = "WSI.pth"
    size_in_bytes = 31 * 1024 * 1024  # 542 MB
    generate_random_binary_file(file_path, size_in_bytes)
    print(f"File generated: {file_path}")

