import torch
import torch.nn as nn
import torchvision.models as models
import matplotlib.pyplot as plt
import seaborn as sns


class CrossAttentionLayer(nn.Module):
    def __init__(self, input_dim):
        super(CrossAttentionLayer, self).__init__()
        self.linear1 = nn.Linear(input_dim, input_dim)
        self.linear2 = nn.Linear(input_dim, input_dim)
        self.softmax = nn.Softmax(dim=-1)
        self.dropout = nn.Dropout(0.1)

    def forward(self, x, y):
        # Compute attention scores
        scores = torch.matmul(self.linear1(x), self.linear2(y).transpose(-2, -1))
        attn_weights = self.softmax(scores)

        # Apply attention weights to y
        y_attended = torch.matmul(attn_weights, y)

        # Apply dropout
        y_attended = self.dropout(y_attended)

        return y_attended

# Load the model
model = torch.load("MRI.pth")

image_T1 = './data/T1.jpg'
image_T2 = './data/T1.jpg'

def visualize_attention(model, image_T1, image_T2):
    model.eval()
    with torch.no_grad():

        outputs = model(image_T1.unsqueeze(0), image_T2.unsqueeze(0))  # Assuming batch size of 1
        cross_attention_outputs = model.cross_attention.attention_weights.cpu().numpy()  # Get cross-attention outputs
        cross_attention_outputs = cross_attention_outputs.reshape(8, 8)  # Reshape to 8x8


    plt.figure(figsize=(8, 8))
    ax = sns.heatmap(cross_attention_outputs, annot=True, cmap="YlGnBu")
    ax.set_title("Cross-Attention Patch Attention Map")
    ax.set_xlabel("T1 Patch Index")
    ax.set_ylabel("T2 Patch Index")
    plt.show()


visualize_attention(model, image_T1, image_T2)
