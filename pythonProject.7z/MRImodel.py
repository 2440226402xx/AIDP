import torch
import torch.nn as nn
import torchvision.transforms as transforms
import torchvision.models as models
import torch.optim as optim
from torch.optim.lr_scheduler import StepLR
from torch.utils.data import Dataset, DataLoader
import pandas as pd
from PIL import Image
import os

class CrossAttentionLayer(nn.Module):
    def __init__(self, input_dim):
        super(CrossAttentionLayer, self).__init__()
        self.linear1 = nn.Linear(input_dim, input_dim)
        self.linear2 = nn.Linear(input_dim, input_dim)
        self.softmax = nn.Softmax(dim=-1)
        self.dropout = nn.Dropout(0.1)

    def forward(self, x, y):
        # Compute attention scores
        scores = torch.matmul(self.linear1(x), self.linear2(y).transpose(-2, -1))
        attn_weights = self.softmax(scores)

        # Apply attention weights to y
        y_attended = torch.matmul(attn_weights, y)

        # Apply dropout
        y_attended = self.dropout(y_attended)

        return y_attended


class CrossAttentionVisionTransformer(nn.Module):
    def __init__(self, num_classes):
        super(CrossAttentionVisionTransformer, self).__init__()
        self.vision_transformer = models.vit_base_patch16_224_in21k(pretrained=True)
        self.patch_size = 8
        self.num_patches = (224 // self.patch_size) * (224 // self.patch_size)
        self.cross_attention = CrossAttentionLayer(
            768)  # Assuming vit_base_patch16_224_in21k model output dimension is 768
        self.fc = nn.Linear(768 * self.num_patches, num_classes)

    def forward(self, T1_images, T2_images):
        # Vision transformer forward pass
        T1_outputs = self.vision_transformer(T1_images)  # Shape: [batch_size, num_patches, embed_dim]
        T2_outputs = self.vision_transformer(T2_images)  # Shape: [batch_size, num_patches, embed_dim]

        # Reshape outputs into patches
        T1_outputs = T1_outputs.view(T1_outputs.size(0), self.num_patches,
                                     -1)  # Shape: [batch_size, num_patches, embed_dim]
        T2_outputs = T2_outputs.view(T2_outputs.size(0), self.num_patches,
                                     -1)  # Shape: [batch_size, num_patches, embed_dim]

        # Cross-attention
        T1_outputs_attended = self.cross_attention(T1_outputs,
                                                   T2_outputs)  # Shape: [batch_size, num_patches, embed_dim]
        T2_outputs_attended = self.cross_attention(T2_outputs,
                                                   T1_outputs)  # Shape: [batch_size, num_patches, embed_dim]

        # Concatenate attended features
        combined_features = torch.cat((T1_outputs_attended, T2_outputs_attended),
                                      dim=-1)  # Shape: [batch_size, num_patches, 2 * embed_dim]

        # Flatten for classification
        combined_features = combined_features.view(combined_features.size(0),
                                                   -1)  # Shape: [batch_size, num_patches * 2 * embed_dim]

        # Classify
        output = self.fc(combined_features)

        return output


augmentation_transforms = transforms.Compose([
    transforms.RandomVerticalFlip(),
    transforms.RandomHorizontalFlip(),
    transforms.RandomAffine(degrees=15, translate=(0.1, 0.1), scale=(0.9, 1.1)),
    transforms.RandomRotation(degrees=15),
    transforms.GaussianBlur(kernel_size=3),
    transforms.RandomPerspective(distortion_scale=0.5, p=0.5),
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])  # Normalize with ImageNet stats
])


# Load data
data_frame = pd.read_csv('your_data.csv')  # Load your CSV file
train_data, val_data = train_test_split(data_frame, test_size=0.2, random_state=42)  # Split data into train and validation sets

class CustomDataset(Dataset):
    def __init__(self, dataframe, root_dir_T1, root_dir_T2, transform=None):
        self.dataframe = dataframe
        self.root_dir_T1 = root_dir_T1
        self.root_dir_T2 = root_dir_T2
        self.transform = transform

    def __len__(self):
        return len(self.dataframe)

    def __getitem__(self, idx):
        img_name_T1 = os.path.join(self.root_dir_T1, self.dataframe.iloc[idx, 0])
        img_name_T2 = os.path.join(self.root_dir_T2, self.dataframe.iloc[idx, 0])

        image_T1 = Image.open(img_name_T1)
        image_T2 = Image.open(img_name_T2)

        if self.transform:
            image_T1 = self.transform(image_T1)
            image_T2 = self.transform(image_T2)

        label = self.dataframe.iloc[idx, 1]

        return (image_T1, image_T2), label

augmentation_transforms = transforms.Compose([
    transforms.RandomVerticalFlip(),
    transforms.RandomHorizontalFlip(),
    transforms.RandomAffine(degrees=15, translate=(0.1, 0.1), scale=(0.9, 1.1)),
    transforms.RandomRotation(degrees=15),
    transforms.GaussianBlur(kernel_size=3),
    transforms.RandomPerspective(distortion_scale=0.5, p=0.5),
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])  # Normalize with ImageNet stats
])

train_dataset = CustomDataset(train_data, root_dir_T1='/data/MRIimg/trainset/T1', root_dir_T2='/data/MRIimg/trainset/T1', transform=augmentation_transforms)
val_dataset = CustomDataset(val_data, root_dir_T1='/data/MRIimg/valset/T1', root_dir_T2='/data/MRIimg/valset/T1', transform=transforms.ToTensor())  # No augmentation for validation

train_loader = DataLoader(train_dataset, batch_size=8, shuffle=True)
val_loader = DataLoader(val_dataset, batch_size=8, shuffle=False)

model = CrossAttentionVisionTransformer(num_classes=7)
optimizer = optim.Adam(model.parameters(), lr=1e-4)
scheduler = StepLR(optimizer, step_size=50, gamma=0.1)
# Define Focus Loss
class FocusLoss(nn.Module):
    def __init__(self, alpha=0.25, gamma=2):
        super(FocusLoss, self).__init__()
        self.alpha = alpha
        self.gamma = gamma

    def forward(self, input, target):
        ce_loss = F.cross_entropy(input, target, reduction='none')
        pt = torch.exp(-ce_loss)
        focal_loss = self.alpha * (1 - pt) ** self.gamma * ce_loss
        return torch.mean(focal_loss)

# Initialize Focus Loss
focus_loss_function = FocusLoss()

# Combine CrossEntropyLoss with FocusLoss based on label counts
def combined_loss(outputs, labels):
    num_classes = 7
    num_binary_classes = 6
    num_samples = len(labels)
    binary_labels = labels < num_binary_classes  # Binary labels (0-1)
    ternary_labels = labels  # Ternary labels (0-1-2)

    # Compute loss for binary classification
    binary_outputs = outputs[:, :num_binary_classes]
    binary_targets = torch.where(binary_labels, labels, torch.zeros_like(labels))
    binary_loss = focus_loss_function(binary_outputs, binary_targets)

    # Compute loss for ternary classification
    ternary_outputs = outputs[:, num_binary_classes:]
    ternary_targets = torch.where(binary_labels, torch.zeros_like(labels), ternary_labels - num_binary_classes)
    ternary_loss = F.cross_entropy(ternary_outputs, ternary_targets)

    # Combine losses
    total_loss = (binary_loss + ternary_loss) / num_samples

    return total_loss

num_iterations = 500
iteration = 0
while iteration < num_iterations:
    model.train()
    scheduler.step()
    for batch_idx, ((T1_images, T2_images), labels) in enumerate(train_loader):
        optimizer.zero_grad()
        outputs = model(T1_images, T2_images)
        loss = loss_function(outputs, labels)
        loss.backward()
        optimizer.step()

        iteration += 1
        if iteration >= num_iterations:
            break

    if iteration % 10 == 0:
        model.eval()
        val_loss = 0
        correct = 0
        total = 0
        with torch.no_grad():
            for batch_idx, ((T1_images, T2_images), labels) in enumerate(val_loader):
                outputs = model(T1_images, T2_images)
                val_loss += loss_function(outputs, labels).item()
                _, predicted = outputs.max(1)
                total += labels.size(0)
                correct += predicted.eq(labels).sum().item()

        # Print validation loss and accuracy
        val_loss /= len(val_loader.dataset)
        accuracy = 100. * correct / total
        print(f'Iteration {iteration}/{num_iterations}, Validation Loss: {val_loss:.4f}, Validation Accuracy: {accuracy:.2f}%')
